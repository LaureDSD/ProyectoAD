package ProyectoFinalLaureano.ProyectoFinalLaureano.models.personaje.enums;

public enum EstadoMision {
    EN_PROGRESO,
    COMPLETADA,
    FALLIDA
}
