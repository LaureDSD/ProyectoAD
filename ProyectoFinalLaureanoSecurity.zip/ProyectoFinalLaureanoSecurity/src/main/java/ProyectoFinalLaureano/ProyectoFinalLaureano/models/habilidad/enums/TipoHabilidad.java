package ProyectoFinalLaureano.ProyectoFinalLaureano.models.habilidad.enums;

public enum TipoHabilidad {
    OFENSIVA,
    DEFENSIVA,
    APOYO
}