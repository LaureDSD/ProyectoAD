package ProyectoFinalLaureano.ProyectoFinalLaureano.models.habilidad.enums;

public enum ObjetivoHabilidad {
    JUGADOR,
    ALIADO,
    ENEMIGO, TODO
}
