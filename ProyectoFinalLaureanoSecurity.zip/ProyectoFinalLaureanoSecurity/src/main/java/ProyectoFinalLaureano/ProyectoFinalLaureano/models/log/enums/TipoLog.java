package ProyectoFinalLaureano.ProyectoFinalLaureano.models.log.enums;

public enum TipoLog {
    INFORMACION,
    FALLO,
    ADVERTENCIA,
    CREACION,
    ACTUALIZACION,
    BORRADO
}
