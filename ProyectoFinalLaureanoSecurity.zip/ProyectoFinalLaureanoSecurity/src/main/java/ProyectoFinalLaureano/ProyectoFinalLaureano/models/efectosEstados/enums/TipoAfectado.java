package ProyectoFinalLaureano.ProyectoFinalLaureano.models.efectosEstados.enums;

public enum TipoAfectado {
    PERSONAJE,
    MONSTRUO,
    TODO
}
