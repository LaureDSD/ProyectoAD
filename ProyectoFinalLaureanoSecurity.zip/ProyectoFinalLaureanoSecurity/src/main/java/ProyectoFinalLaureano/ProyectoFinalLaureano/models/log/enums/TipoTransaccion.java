package ProyectoFinalLaureano.ProyectoFinalLaureano.models.log.enums;

public enum TipoTransaccion {
    COMPRA,
    VENTA
}
