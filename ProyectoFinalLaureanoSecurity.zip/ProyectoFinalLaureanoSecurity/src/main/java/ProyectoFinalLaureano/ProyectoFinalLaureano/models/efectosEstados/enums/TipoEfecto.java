package ProyectoFinalLaureano.ProyectoFinalLaureano.models.efectosEstados.enums;


public enum TipoEfecto {
    BUFF,
    DEBUFF
}