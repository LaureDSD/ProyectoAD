package ProyectoFinalLaureano.ProyectoFinalLaureano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalApiLaureanoApplicationTests {

	@Test
	void contextLoads() {
	}

}
